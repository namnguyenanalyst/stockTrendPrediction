"""Client kết nối dịch vụ SSI Fast Connect Data (FC-Data) để thu thập dữ liệu chứng khoán chuyên nghiệp."""

from datetime import datetime, timedelta
import logging
import os
from pathlib import Path
import time
from typing import Any

from dotenv import load_dotenv
import pandas as pd
import requests

from vn_stock.config import MONOREPO_ROOT, PROJ_ROOT

logger = logging.getLogger(__name__)

# Tự động nạp cấu hình từ .env ở root repo hoặc apps/ml hoặc cwd
for env_path in [
    MONOREPO_ROOT / ".env",
    PROJ_ROOT / ".env",
    Path.cwd() / ".env",
    Path(__file__).resolve().parents[3] / ".env",
]:
    if env_path.exists():
        load_dotenv(env_path)


class SSIFastConnectClient:
    """Client giao tiếp với SSI Fast Connect Market Data API."""

    def __init__(
        self,
        consumer_id: str | None = None,
        consumer_secret: str | None = None,
        api_url: str | None = None,
    ):
        self.consumer_id = consumer_id or os.getenv("SSI_CONSUMER_ID", "")
        self.consumer_secret = consumer_secret or os.getenv("SSI_CONSUMER_SECRET", "")
        self.api_url = (api_url or os.getenv("SSI_API_URL", "https://fc-data.ssi.com.vn/")).rstrip(
            "/"
        ) + "/"

        self._access_token: str | None = None
        self._token_expiry: datetime | None = None
        self._session = requests.Session()
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _get_access_token(self) -> str:
        """Lấy JWT Access Token từ SSI hoặc tái sử dụng token đã cache nếu còn hạn."""
        now = datetime.now()  # noqa: DTZ005
        if (
            self._access_token is not None
            and self._token_expiry is not None
            and now < self._token_expiry
        ):
            return self._access_token

        if not self.consumer_id or not self.consumer_secret:
            raise ValueError(
                "Chưa cấu hình SSI_CONSUMER_ID hoặc SSI_CONSUMER_SECRET trong file .env."
            )

        url = self.api_url + "api/v2/Market/AccessToken"
        payload = {
            "consumerID": self.consumer_id,
            "consumerSecret": self.consumer_secret,
        }

        last_err = None
        for attempt in range(3):
            try:
                response = self._session.post(url, json=payload, headers=self._headers, timeout=30)
                response.raise_for_status()
                data = response.json()
                if data.get("status") == 200 and "data" in data:
                    self._access_token = data["data"]["accessToken"]
                    self._token_expiry = now + timedelta(hours=6)
                    return self._access_token
                else:
                    raise RuntimeError(f"Lỗi xác thực SSI FC-Data: {data.get('message')}")
            except Exception as exc:
                last_err = exc
                logger.warning("Lấy AccessToken SSI lần %d/3 thất bại: %s", attempt + 1, exc)
                time.sleep(1.0)

        raise RuntimeError(f"Không thể lấy JWT Access Token từ SSI sau 3 lần thử: {last_err}") from last_err

    def _format_date_for_ssi(self, date_str: str) -> str:
        """Chuyển định dạng YYYY-MM-DD sang DD/MM/YYYY theo chuẩn SSI API."""
        try:
            # Nếu đã là định dạng DD/MM/YYYY
            if "/" in date_str:
                return date_str
            dt = datetime.strptime(date_str, "%Y-%m-%d")  # noqa: DTZ007
            return dt.strftime("%d/%m/%Y")
        except (ValueError, TypeError):
            return date_str

    def get_daily_ohlcv(
        self,
        symbol: str,
        start_date: str = "2020-01-01",
        end_date: str | None = None,
        unit: str = "kVND",  # "kVND" (chia 1000 để tương thích dự án cũ) hoặc "VND"
    ) -> pd.DataFrame:
        """
        Truy vấn nến lịch sử ngày (Daily OHLCV) có hỗ trợ phân trang tự động và retry.

        Args:
            symbol: Mã cổ phiếu (VIC, FPT, HPG, ...)
            start_date: Ngày bắt đầu (YYYY-MM-DD hoặc DD/MM/YYYY)
            end_date: Ngày kết thúc (mặc định là ngày hiện tại)
            unit: 'kVND' (nghìn đồng - chia 1000) hoặc 'VND' (đồng nguyên giá)
        """
        token = self._get_access_token()
        headers = {
            **self._headers,
            "Authorization": f"Bearer {token}",
        }

        from_date_ssi = self._format_date_for_ssi(start_date)
        if end_date is None:
            to_date_ssi = datetime.now().strftime("%d/%m/%Y")  # noqa: DTZ005
        else:
            to_date_ssi = self._format_date_for_ssi(end_date)

        all_records: list[dict[str, Any]] = []
        page_index = 1
        page_size = 1000

        while True:
            params = {
                "symbol": symbol.upper(),
                "fromDate": from_date_ssi,
                "toDate": to_date_ssi,
                "pageIndex": page_index,
                "pageSize": page_size,
                "ascending": True,
            }

            url = self.api_url + "api/v2/Market/DailyOhlc"
            res_data = None
            last_err = None

            for attempt in range(3):
                try:
                    res = self._session.get(url, params=params, headers=headers, timeout=30)
                    res.raise_for_status()
                    res_data = res.json()
                    status_str = str(res_data.get("status", "")).lower()
                    if status_str in ["200", "success"]:
                        break
                    else:
                        last_err = RuntimeError(f"API trả về status {status_str}: {res_data.get('message')}")
                except Exception as exc:
                    last_err = exc
                logger.warning("Truy vấn DailyOhlc %s trang %d lần %d/3 thất bại: %s", symbol, page_index, attempt + 1, last_err)
                time.sleep(1.2)

            if res_data is None:
                raise RuntimeError(f"Lỗi truy vấn DailyOhlc {symbol} sau 3 lần thử: {last_err}") from last_err

            status_str = str(res_data.get("status", "")).lower()
            if status_str not in ["200", "success"]:
                raise RuntimeError(f"Lỗi truy vấn DailyOhlc {symbol}: {res_data.get('message')}")

            data_batch = res_data.get("data", [])
            if not data_batch:
                break

            all_records.extend(data_batch)

            total_record = res_data.get("totalRecord", 0)
            if len(all_records) >= total_record or len(data_batch) < page_size:
                break

            page_index += 1

        if not all_records:
            return pd.DataFrame(columns=["Date", "Open", "High", "Low", "Close", "Volume"])

        df = pd.DataFrame(all_records)

        # Chuẩn hóa cột
        df["Date"] = pd.to_datetime(df["TradingDate"], format="%d/%m/%Y")
        for col in ["Open", "High", "Low", "Close", "Volume"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        # Quy đổi đơn vị giá nếu cần (mặc định kVND để đồng bộ với VN_Stock)
        if unit == "kVND":
            price_cols = ["Open", "High", "Low", "Close"]
            for col in price_cols:
                if col in df.columns:
                    df[col] = df[col] / 1000.0

        # Sắp xếp theo ngày tăng dần
        df = df.sort_values("Date").reset_index(drop=True)

        return df[["Date", "Open", "High", "Low", "Close", "Volume"]]

    def get_index_components(self, index_code: str = "VN30") -> list[str]:
        """Lấy danh sách các mã cổ phiếu trong rổ chỉ số (VN30, VN100, ...)."""
        token = self._get_access_token()
        headers = {
            **self._headers,
            "Authorization": f"Bearer {token}",
        }
        url = self.api_url + "api/v2/Market/IndexComponents"
        params = {"indexCode": index_code.upper(), "pageIndex": 1, "pageSize": 100}

        res = self._session.get(url, params=params, headers=headers, timeout=15)
        res.raise_for_status()
        data = res.json()

        status_str = str(data.get("status", "")).lower()
        if status_str not in ["200", "success"]:
            raise RuntimeError(f"Lỗi lấy rổ chỉ số {index_code}: {data.get('message')}")

        result_symbols: list[str] = []
        data_list = data.get("data", [])
        if isinstance(data_list, list):
            for index_group in data_list:
                components = index_group.get("IndexComponent", [])
                for comp in components:
                    symbol = comp.get("StockSymbol") or comp.get("Isin")
                    if symbol and symbol not in result_symbols:
                        result_symbols.append(symbol)

        return result_symbols

    def get_daily_index(
        self,
        index_id: str = "VNINDEX",
        start_date: str = "2023-01-01",
        end_date: str | None = None,
        chunk_days: int = 25,
    ) -> pd.DataFrame:
        """
        Truy vấn chuỗi chỉ số thị trường lịch sử (VNINDEX, VN30, ...) từ SSI FC-Data API.
        Tự động phân đoạn chu kỳ truy vấn (chunk 25 ngày) và áp dụng cơ chế retry + rate limit.
        """
        token = self._get_access_token()
        headers = {
            **self._headers,
            "Authorization": f"Bearer {token}",
        }
        url = self.api_url + "api/v2/Market/DailyIndex"

        start_dt = (
            datetime.strptime(start_date, "%Y-%m-%d")  # noqa: DTZ007
            if "-" in start_date
            else datetime.strptime(start_date, "%d/%m/%Y")  # noqa: DTZ007
        )
        if end_date is None:
            end_dt = datetime.now()  # noqa: DTZ005
        else:
            end_dt = (
                datetime.strptime(end_date, "%Y-%m-%d")  # noqa: DTZ007
                if "-" in end_date
                else datetime.strptime(end_date, "%d/%m/%Y")  # noqa: DTZ007
            )

        records: list[dict[str, Any]] = []
        cur_start = start_dt

        while cur_start <= end_dt:
            cur_end = min(cur_start + timedelta(days=chunk_days), end_dt)
            params = {
                "indexId": index_id.upper(),
                "fromDate": cur_start.strftime("%d/%m/%Y"),
                "toDate": cur_end.strftime("%d/%m/%Y"),
                "pageIndex": 1,
                "pageSize": 100,
                "ascending": True,
            }
            # Cơ chế Thử lại (Retry) tối đa 3 lần cho mỗi chunk
            chunk_success = False
            last_err_msg = ""
            for attempt in range(3):
                try:
                    res = self._session.get(url, params=params, headers=headers, timeout=15)
                    if res.status_code == 200:
                        d = res.json()
                        status_str = str(d.get("status", "")).lower()
                        if status_str in ["200", "success"]:
                            if d.get("data"):
                                records.extend(d["data"])
                            chunk_success = True
                            break
                        else:
                            last_err_msg = f"API trả về status {status_str}: {d.get('message')}"
                            logger.warning(
                                "Truy vấn %s chunk [%s -> %s] lần %d/3 không thành công: %s",
                                index_id,
                                cur_start.strftime("%d/%m/%Y"),
                                cur_end.strftime("%d/%m/%Y"),
                                attempt + 1,
                                last_err_msg,
                            )
                    else:
                        last_err_msg = f"HTTP status {res.status_code}: {res.text[:100]}"
                        logger.warning(
                            "Truy vấn %s chunk [%s -> %s] lần %d/3 lỗi HTTP %d",
                            index_id,
                            cur_start.strftime("%d/%m/%Y"),
                            cur_end.strftime("%d/%m/%Y"),
                            attempt + 1,
                            res.status_code,
                        )
                except Exception as exc:  # noqa: BLE001
                    last_err_msg = str(exc)
                    logger.warning(
                        "Truy vấn %s chunk [%s -> %s] lần %d/3 gặp ngoại lệ: %s",
                        index_id,
                        cur_start.strftime("%d/%m/%Y"),
                        cur_end.strftime("%d/%m/%Y"),
                        attempt + 1,
                        exc,
                    )
                time.sleep(1.2)

            if not chunk_success:
                raise RuntimeError(
                    f"Truy vấn {index_id} thất bại sau 3 lần thử cho khoảng ngày "
                    f"[{cur_start.strftime('%d/%m/%Y')} -> {cur_end.strftime('%d/%m/%Y')}]: {last_err_msg}"
                )

            cur_start = cur_end + timedelta(days=1)
            time.sleep(1.05)  # Tránh vượt quá rate limit của SSI API

        close_col = f"{index_id.upper()}_Close"
        if not records:
            return pd.DataFrame(columns=["Date", close_col])

        df = pd.DataFrame(records)
        df["Date"] = pd.to_datetime(df["TradingDate"], format="%d/%m/%Y")
        df[close_col] = pd.to_numeric(df["IndexValue"], errors="coerce")
        df = df.drop_duplicates(subset=["Date"]).sort_values("Date").reset_index(drop=True)
        return df[["Date", close_col]]
