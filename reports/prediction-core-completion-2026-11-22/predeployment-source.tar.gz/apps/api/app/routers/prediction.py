"""Router quản lý các endpoint suy luận dự báo xu hướng thị trường (AI Inference)."""

import json

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.core.config import settings
from app.core.deps import get_current_active_user, verify_internal_worker_secret
from app.db.models.user import User
from app.models.schemas import BatchPredictionResponse, LiveSyncRequest, PredictionResponse
from app.services import prediction_service

router = APIRouter(prefix="/predict", tags=["AI Prediction"])


class PredictionSignalRequest(BaseModel):
    symbol: str = Field(default="VIC", description="Mã cổ phiếu cần dự báo (ví dụ: VIC, HPG, FPT)")
    model_type: str = Field(default="lightgbm", description="Loại mô hình AI ('lightgbm' hoặc 'lstm')")


class BatchPredictionRequest(BaseModel):
    model_type: str = Field(default="lightgbm", description="Loại mô hình AI ('lightgbm' hoặc 'lstm')")
    symbols: list[str] | None = Field(default=None, description="Danh sách mã cổ phiếu tùy chọn")
    scope: str = Field(default="VN30", description="Phạm vi danh mục: 'VN30' hoặc 'CORE'")


@router.get(
    "/signal",
    response_model=PredictionResponse,
    summary="Dự báo xu hướng chu kỳ T+3 và Quỹ đạo 3 phiên cho một mã cổ phiếu (GET)",
    description="Thực hiện suy luận bằng mô hình LightGBM hoặc PyTorch Global LSTM, trả về xác suất 3 lớp và khuyến nghị Mua/Bán.",
)
def predict_signal(
    symbol: str = Query("VIC", description="Mã cổ phiếu cần dự báo (ví dụ: VIC, HPG, FPT)"),
    model_type: str = Query("lightgbm", description="Loại mô hình AI ('lightgbm' hoặc 'lstm')"),
) -> PredictionResponse:
    """Endpoint suy luận tín hiệu đầu tư cho một mã qua GET query params."""
    return prediction_service.predict_stock_signal(
        symbol=symbol,
        model_type=model_type,
    )


@router.post(
    "/signal",
    response_model=PredictionResponse,
    summary="Dự báo xu hướng chu kỳ T+3 và Quỹ đạo 3 phiên cho một mã cổ phiếu (POST)",
    description="Thực hiện suy luận bằng mô hình LightGBM hoặc PyTorch Global LSTM nhận body JSON.",
)
def predict_signal_post(request: PredictionSignalRequest) -> PredictionResponse:
    """Endpoint suy luận tín hiệu đầu tư cho một mã qua POST body."""
    return prediction_service.predict_stock_signal(
        symbol=request.symbol,
        model_type=request.model_type,
    )


@router.get(
    "/batch",
    response_model=BatchPredictionResponse,
    summary="Dự báo đồng loạt cho danh mục cổ phiếu (GET)",
    description="Chạy dự báo xu hướng song song cho danh mục cổ phiếu (mặc định toàn bộ 30 mã VN30 hoặc 5 mã CORE).",
)
def predict_batch(
    model_type: str = Query("lightgbm", description="Loại mô hình AI ('lightgbm' hoặc 'lstm')"),
    scope: str = Query("VN30", description="Phạm vi danh mục: 'VN30' hoặc 'CORE'"),
) -> BatchPredictionResponse:
    """Endpoint dự báo danh mục cổ phiếu qua GET."""
    return prediction_service.predict_batch_signals(model_type=model_type, scope=scope)


@router.post(
    "/batch",
    response_model=BatchPredictionResponse,
    summary="Dự báo đồng loạt cho danh mục cổ phiếu (POST)",
    description="Chạy dự báo xu hướng song song cho danh mục cổ phiếu qua POST body.",
)
def predict_batch_post(
    request: BatchPredictionRequest,
) -> BatchPredictionResponse:
    """Endpoint dự báo danh mục cổ phiếu qua POST."""
    return prediction_service.predict_batch_signals(
        model_type=request.model_type,
        symbols=request.symbols,
        scope=request.scope,
    )


@router.post(
    "/live",
    dependencies=[Depends(get_current_active_user)],
    response_model=PredictionResponse,
    summary="Đồng bộ dữ liệu phiên gần nhất và dự báo Live chu kỳ T+3 (POST)",
    description="Kết nối dữ liệu mới nhất (Near-realtime) và xuất tín hiệu khuyến nghị cho chu kỳ T+3 cùng Quỹ đạo 3 phiên.",
)
def predict_live_post(request: LiveSyncRequest) -> PredictionResponse:
    """Endpoint đồng bộ và suy luận trực tuyến nhận body JSON."""
    return prediction_service.sync_live_and_predict(
        symbol=request.symbol,
        model_type=request.model_type,
    )


@router.get(
    "/live",
    dependencies=[Depends(get_current_active_user)],
    response_model=PredictionResponse,
    summary="Đồng bộ dữ liệu phiên gần nhất và dự báo Live chu kỳ T+3 (GET)",
    description="Kết nối dữ liệu mới nhất (Near-realtime) và xuất tín hiệu khuyến nghị cho chu kỳ T+3 cùng Quỹ đạo 3 phiên qua GET query.",
)
def predict_live_get(
    symbol: str = Query("VIC", description="Mã cổ phiếu cần dự báo (ví dụ: VIC, HPG, FPT)"),
    model_type: str = Query("lightgbm", description="Loại mô hình AI ('lightgbm' hoặc 'lstm')"),
) -> PredictionResponse:
    """Endpoint đồng bộ và suy luận trực tuyến qua GET."""
    return prediction_service.sync_live_and_predict(
        symbol=symbol,
        model_type=model_type,
    )


class RetrainRequest(BaseModel):
    horizon: int = Field(default=3, ge=1, le=20, description="Chân trời dự báo (mặc định 3 phiên T+3)")
    threshold: float = Field(default=0.02, gt=0, lt=1, description="Ngưỡng biến động giá (mặc định 2.0%)")
    val_buffer_days: int = Field(default=40, ge=5, le=252, description="Số phiên đệm validation Early Stopping")
    scope: str = Field(default="VN30", pattern="^(VN30|CORE)$", description="Phạm vi danh mục")


@router.post(
    "/retrain",
    dependencies=[Depends(verify_internal_worker_secret)],
    summary="Huấn luyện lại mô hình thực chiến T+3 (POST)",
    description="Tự động thu thập dữ liệu tới phiên T-1 (hoặc T sau 15:00) và huấn luyện lại LightGBM + PyTorch LSTM trên toàn bộ dữ liệu tích lũy.",
)
def retrain_model_endpoint(
    request: RetrainRequest = RetrainRequest(),
) -> dict:
    """Endpoint kích hoạt huấn luyện lại mô hình sản xuất."""
    return prediction_service.retrain_production_system(
        horizon=request.horizon,
        threshold=request.threshold,
        val_buffer_days=request.val_buffer_days,
        scope=request.scope,
    )


class PredictStatusResponse(BaseModel):
    last_atc_session_date: str
    last_retrain_at: str | None = None


@router.get(
    "/status",
    response_model=PredictStatusResponse,
    summary="Trạng thái phiên ATC và thời điểm retrain mô hình",
    description="Truy vấn ngày chốt nến ATC gần nhất và thời điểm huấn luyện lại mô hình gần nhất.",
)
def get_predict_status(
    current_user: User = Depends(get_current_active_user),
) -> PredictStatusResponse:
    """Endpoint trả về ngày chốt nến ATC và thời điểm retrain gần nhất."""
    from vn_stock.market_session import get_target_market_date

    last_atc = get_target_market_date()

    last_retrain = None
    prod_info_file = settings.MODELS_DIR / "production_training_info_t3.json"
    bundle = settings.MODELS_DIR / "production_bundle_t3.json"
    if bundle.exists():
        from vn_stock.modeling.artifacts import resolve_bundle
        try:
            prod_info_file = resolve_bundle(settings.MODELS_DIR, 3)["production_training_info_t3.json"]
        except (OSError, ValueError, KeyError):
            raise HTTPException(503, "Không thể xác minh bộ mô hình hiện tại.") from None
    if prod_info_file.exists():
        try:
            content = prod_info_file.read_text(encoding="utf-8")
            data = json.loads(content)
            last_retrain = data.get("timestamp")
        except (OSError, json.JSONDecodeError, KeyError):
            last_retrain = None

    return PredictStatusResponse(
        last_atc_session_date=last_atc,
        last_retrain_at=last_retrain,
    )


